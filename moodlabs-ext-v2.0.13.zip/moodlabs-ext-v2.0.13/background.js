var M;
(function(e) {
  e.Local = "local", e.Sync = "sync", e.Managed = "managed", e.Session = "session";
})(M || (M = {}));
var I;
(function(e) {
  e.ExtensionPagesOnly = "TRUSTED_CONTEXTS", e.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(I || (I = {}));
const x = globalThis.chrome, $ = async (e, i) => {
  const r = (n) => typeof n == "function", g = (n) => (
    // Use ReturnType to infer the return type of the function and check if it's a Promise
    n instanceof Promise
  );
  return r(e) ? (g(e), e(i)) : e;
};
let U = !1;
const W = (e) => {
  if (x && !x.storage[e])
    throw new Error(`"storage" permission in manifest.ts: "storage ${e}" isn't defined`);
}, V = (e, i, r) => {
  var k, F;
  let g = null, n = !1, l = [];
  const A = (r == null ? void 0 : r.storageEnum) ?? M.Local, p = ((k = r == null ? void 0 : r.serialization) == null ? void 0 : k.serialize) ?? ((c) => c), v = ((F = r == null ? void 0 : r.serialization) == null ? void 0 : F.deserialize) ?? ((c) => c);
  U === !1 && A === M.Session && (r == null ? void 0 : r.sessionAccessForContentScripts) === !0 && (W(A), x == null || x.storage[A].setAccessLevel({
    accessLevel: I.ExtensionPagesAndContentScripts
  }).catch((c) => {
    console.error(c), console.error("Please call .setAccessLevel() into different context, like a background script.");
  }), U = !0);
  const S = async () => {
    W(A);
    const c = await (x == null ? void 0 : x.storage[A].get([e]));
    return c ? v(c[e]) ?? i : i;
  }, w = async (c) => {
    n || (g = await S()), g = await $(c, g), await (x == null ? void 0 : x.storage[A].set({ [e]: p(g) })), T();
  }, D = (c) => (l = [...l, c], () => {
    l = l.filter((E) => E !== c);
  }), N = () => g, T = () => {
    l.forEach((c) => c());
  }, C = async (c) => {
    if (c[e] === void 0)
      return;
    const E = v(c[e].newValue);
    g !== E && (g = await $(E, g), T());
  };
  return S().then((c) => {
    g = c, n = !0, T();
  }), x == null || x.storage[A].onChanged.addListener(C), {
    get: S,
    set: w,
    getSnapshot: N,
    subscribe: D
  };
}, q = V("theme-storage-key", {
  theme: "light",
  isLight: !0
}, {
  storageEnum: M.Local
}), J = {
  ...q,
  toggle: async () => {
    await q.set((e) => {
      const i = e.theme === "light" ? "dark" : "light";
      return {
        theme: i,
        isLight: i === "light"
      };
    });
  }
};
var R = { exports: {} }, K = R.exports, z;
function X() {
  return z || (z = 1, (function(e, i) {
    (function(r, g) {
      g(e);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : K, function(r) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        r.exports = globalThis.browser;
      else {
        const g = "The message port closed before a response was received.", n = (l) => {
          const A = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(A).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class p extends WeakMap {
            constructor(t, o = void 0) {
              super(o), this.createItem = t;
            }
            get(t) {
              return this.has(t) || this.set(t, this.createItem(t)), super.get(t);
            }
          }
          const v = (s) => s && typeof s == "object" && typeof s.then == "function", S = (s, t) => (...o) => {
            l.runtime.lastError ? s.reject(new Error(l.runtime.lastError.message)) : t.singleCallbackArg || o.length <= 1 && t.singleCallbackArg !== !1 ? s.resolve(o[0]) : s.resolve(o);
          }, w = (s) => s == 1 ? "argument" : "arguments", D = (s, t) => function(m, ...d) {
            if (d.length < t.minArgs)
              throw new Error(`Expected at least ${t.minArgs} ${w(t.minArgs)} for ${s}(), got ${d.length}`);
            if (d.length > t.maxArgs)
              throw new Error(`Expected at most ${t.maxArgs} ${w(t.maxArgs)} for ${s}(), got ${d.length}`);
            return new Promise((f, h) => {
              if (t.fallbackToNoCallback)
                try {
                  m[s](...d, S({
                    resolve: f,
                    reject: h
                  }, t));
                } catch (a) {
                  console.warn(`${s} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, a), m[s](...d), t.fallbackToNoCallback = !1, t.noCallback = !0, f();
                }
              else t.noCallback ? (m[s](...d), f()) : m[s](...d, S({
                resolve: f,
                reject: h
              }, t));
            });
          }, N = (s, t, o) => new Proxy(t, {
            apply(m, d, f) {
              return o.call(d, s, ...f);
            }
          });
          let T = Function.call.bind(Object.prototype.hasOwnProperty);
          const C = (s, t = {}, o = {}) => {
            let m = /* @__PURE__ */ Object.create(null), d = {
              has(h, a) {
                return a in s || a in m;
              },
              get(h, a, b) {
                if (a in m)
                  return m[a];
                if (!(a in s))
                  return;
                let u = s[a];
                if (typeof u == "function")
                  if (typeof t[a] == "function")
                    u = N(s, s[a], t[a]);
                  else if (T(o, a)) {
                    let P = D(a, o[a]);
                    u = N(s, s[a], P);
                  } else
                    u = u.bind(s);
                else if (typeof u == "object" && u !== null && (T(t, a) || T(o, a)))
                  u = C(u, t[a], o[a]);
                else if (T(o, "*"))
                  u = C(u, t[a], o["*"]);
                else
                  return Object.defineProperty(m, a, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return s[a];
                    },
                    set(P) {
                      s[a] = P;
                    }
                  }), u;
                return m[a] = u, u;
              },
              set(h, a, b, u) {
                return a in m ? m[a] = b : s[a] = b, !0;
              },
              defineProperty(h, a, b) {
                return Reflect.defineProperty(m, a, b);
              },
              deleteProperty(h, a) {
                return Reflect.deleteProperty(m, a);
              }
            }, f = Object.create(s);
            return new Proxy(f, d);
          }, k = (s) => ({
            addListener(t, o, ...m) {
              t.addListener(s.get(o), ...m);
            },
            hasListener(t, o) {
              return t.hasListener(s.get(o));
            },
            removeListener(t, o) {
              t.removeListener(s.get(o));
            }
          }), F = new p((s) => typeof s != "function" ? s : function(o) {
            const m = C(o, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            s(m);
          }), c = new p((s) => typeof s != "function" ? s : function(o, m, d) {
            let f = !1, h, a = new Promise((L) => {
              h = function(y) {
                f = !0, L(y);
              };
            }), b;
            try {
              b = s(o, m, h);
            } catch (L) {
              b = Promise.reject(L);
            }
            const u = b !== !0 && v(b);
            if (b !== !0 && !u && !f)
              return !1;
            const P = (L) => {
              L.then((y) => {
                d(y);
              }, (y) => {
                let B;
                y && (y instanceof Error || typeof y.message == "string") ? B = y.message : B = "An unexpected error occurred", d({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: B
                });
              }).catch((y) => {
                console.error("Failed to send onMessage rejected reply", y);
              });
            };
            return P(u ? b : a), !0;
          }), E = ({
            reject: s,
            resolve: t
          }, o) => {
            l.runtime.lastError ? l.runtime.lastError.message === g ? t() : s(new Error(l.runtime.lastError.message)) : o && o.__mozWebExtensionPolyfillReject__ ? s(new Error(o.message)) : t(o);
          }, j = (s, t, o, ...m) => {
            if (m.length < t.minArgs)
              throw new Error(`Expected at least ${t.minArgs} ${w(t.minArgs)} for ${s}(), got ${m.length}`);
            if (m.length > t.maxArgs)
              throw new Error(`Expected at most ${t.maxArgs} ${w(t.maxArgs)} for ${s}(), got ${m.length}`);
            return new Promise((d, f) => {
              const h = E.bind(null, {
                resolve: d,
                reject: f
              });
              m.push(h), o.sendMessage(...m);
            });
          }, H = {
            devtools: {
              network: {
                onRequestFinished: k(F)
              }
            },
            runtime: {
              onMessage: k(c),
              onMessageExternal: k(c),
              sendMessage: j.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: j.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, O = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return A.privacy = {
            network: {
              "*": O
            },
            services: {
              "*": O
            },
            websites: {
              "*": O
            }
          }, C(l, H, A);
        };
        r.exports = n(chrome);
      }
    });
  })(R)), R.exports;
}
X();
J.get().then((e) => {
  console.log("theme", e);
});
console.log("Background loaded");
console.log("Edit 'chrome-extension/src/background/index.ts' and save to reload...");
const Q = (e, i) => {
  if (!e || typeof e != "object")
    return null;
  const r = e, g = Array.isArray(r.alternativeSelectors) ? r.alternativeSelectors.filter(
    (l) => typeof l == "string" && l.trim().length > 0
  ) : [], n = r.confidence;
  return {
    bestSelector: typeof r.bestSelector == "string" && r.bestSelector.trim().length > 0 ? r.bestSelector : null,
    alternativeSelectors: g,
    reason: typeof r.reason == "string" ? r.reason : "",
    confidence: n === "low" || n === "medium" || n === "high" ? n : "unknown",
    targetStrategyId: typeof r.targetStrategyId == "string" ? r.targetStrategyId : void 0,
    failedStep: typeof r.failedStep == "string" ? r.failedStep : void 0,
    rawText: i
  };
}, Y = 12e3, _ = [], Z = (e) => {
  const i = _.indexOf(e);
  i >= 0 && _.splice(i, 1);
}, ee = (e) => [e.filename, e.finalUrl, e.url, e.referrer].filter(Boolean).join(" ").toLowerCase(), G = (e, i) => e.actionId === "download.single.wav" ? i.includes(".wav") || /\bwav\b/.test(i) : e.actionId === "download.single.mp3" ? i.includes(".mp3") || /\bmp3\b/.test(i) : !0, re = (e) => {
  const i = ee(e), r = [..._].sort((n, l) => n.registeredAt - l.registeredAt), g = r.find(
    (n) => !!n.expectedUuid && i.includes(n.expectedUuid.toLowerCase()) && G(n, i)
  ) ?? r.find((n) => G(n, i)) ?? r.find((n) => !!n.actionId) ?? r[0];
  g && (Z(g), clearTimeout(g.timeoutId), g.sendResponse({
    data: {
      downloadId: e.id,
      filename: e.filename,
      url: e.finalUrl || e.url
    }
  }));
};
chrome.downloads.onCreated.addListener((e) => {
  re(e);
});
chrome.runtime.onMessage.addListener((e, i, r) => {
  var g;
  if (console.log("Received message:", e, "from:", i), e.type === "requestSongs")
    return se(e, i).then((n) => r(n)).catch((n) => r({ error: n.message })), !0;
  if (e.type === "geminiRecover")
    return ne(e.payload.apiKey, e.payload.prompt).then((n) => r(n)).catch(
      (n) => r({
        data: null,
        error: n instanceof Error ? n.message : "Gemini recovery failed."
      })
    ), !0;
  if (e.type === "awaitDownloadStart")
    return te(e, r), !0;
  if (e.type === "openOptionsPage") {
    const n = typeof ((g = e.payload) == null ? void 0 : g.hash) == "string" ? e.payload.hash : "", l = chrome.runtime.getURL(`options/index.html${n}`);
    return chrome.tabs.create({ url: l }).then((A) => r({ data: { tabId: A.id ?? -1 } })).catch(
      (A) => r({
        data: null,
        error: A instanceof Error ? A.message : "Failed to open options page."
      })
    ), !0;
  }
  return !1;
});
const se = async (e, i) => {
  var l, A, p;
  console.log("handleRequestSongs called with payload:", e.payload), console.log("Sender tab:", (l = i.tab) == null ? void 0 : l.id, (A = i.tab) == null ? void 0 : A.url);
  const r = new FormData();
  (p = e.payload) != null && p.id && r.append("id", e.payload.id);
  const n = await (await fetch("http://192.168.86.99:9001/api/song-sets/gen-songs", {
    method: "POST",
    body: r
  })).json();
  return console.log("data", n), n;
}, te = (e, i) => {
  var n, l, A;
  const r = Math.max(1e3, ((n = e.payload) == null ? void 0 : n.timeoutMs) ?? Y), g = {
    sendResponse: i,
    expectedUuid: (l = e.payload) == null ? void 0 : l.uuid,
    actionId: (A = e.payload) == null ? void 0 : A.actionId,
    registeredAt: Date.now(),
    timeoutId: setTimeout(() => {
      Z(g), i({
        data: null,
        error: `다운로드 시작을 ${r}ms 안에 감지하지 못했습니다.`
      });
    }, r)
  };
  _.push(g);
}, ne = async (e, i) => {
  var A, p, v, S;
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${e}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        generationConfig: {
          responseMimeType: "application/json",
          temperature: 0.2
        },
        contents: [
          {
            role: "user",
            parts: [{ text: i }]
          }
        ]
      })
    }
  );
  if (!r.ok) {
    const w = await r.text();
    throw new Error(`Gemini recovery failed: ${r.status} ${w}`);
  }
  const n = ((S = (v = (p = (A = (await r.json()).candidates) == null ? void 0 : A[0]) == null ? void 0 : p.content) == null ? void 0 : v.parts) == null ? void 0 : S.map((w) => w.text ?? "").join(`
`).trim()) ?? "";
  let l = null;
  if (n)
    try {
      l = Q(JSON.parse(n), n);
    } catch {
      l = null;
    }
  return {
    data: {
      text: n,
      suggestion: l
    }
  };
};
