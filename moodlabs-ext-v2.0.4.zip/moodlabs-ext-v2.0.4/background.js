var M;
(function(e) {
  e.Local = "local", e.Sync = "sync", e.Managed = "managed", e.Session = "session";
})(M || (M = {}));
var I;
(function(e) {
  e.ExtensionPagesOnly = "TRUSTED_CONTEXTS", e.ExtensionPagesAndContentScripts = "TRUSTED_AND_UNTRUSTED_CONTEXTS";
})(I || (I = {}));
const x = globalThis.chrome, W = async (e, t) => {
  const r = (m) => typeof m == "function", o = (m) => (
    // Use ReturnType to infer the return type of the function and check if it's a Promise
    m instanceof Promise
  );
  return r(e) ? (o(e), e(t)) : e;
};
let $ = !1;
const U = (e) => {
  if (x && !x.storage[e])
    throw new Error(`"storage" permission in manifest.ts: "storage ${e}" isn't defined`);
}, V = (e, t, r) => {
  var k, R;
  let o = null, m = !1, l = [];
  const c = (r == null ? void 0 : r.storageEnum) ?? M.Local, p = ((k = r == null ? void 0 : r.serialization) == null ? void 0 : k.serialize) ?? ((A) => A), v = ((R = r == null ? void 0 : r.serialization) == null ? void 0 : R.deserialize) ?? ((A) => A);
  $ === !1 && c === M.Session && (r == null ? void 0 : r.sessionAccessForContentScripts) === !0 && (U(c), x == null || x.storage[c].setAccessLevel({
    accessLevel: I.ExtensionPagesAndContentScripts
  }).catch((A) => {
    console.error(A), console.error("Please call .setAccessLevel() into different context, like a background script.");
  }), $ = !0);
  const S = async () => {
    U(c);
    const A = await (x == null ? void 0 : x.storage[c].get([e]));
    return A ? v(A[e]) ?? t : t;
  }, w = async (A) => {
    m || (o = await S()), o = await W(A, o), await (x == null ? void 0 : x.storage[c].set({ [e]: p(o) })), T();
  }, F = (A) => (l = [...l, A], () => {
    l = l.filter((E) => E !== A);
  }), N = () => o, T = () => {
    l.forEach((A) => A());
  }, C = async (A) => {
    if (A[e] === void 0)
      return;
    const E = v(A[e].newValue);
    o !== E && (o = await W(E, o), T());
  };
  return S().then((A) => {
    o = A, m = !0, T();
  }), x == null || x.storage[c].onChanged.addListener(C), {
    get: S,
    set: w,
    getSnapshot: N,
    subscribe: F
  };
}, q = V("theme-storage-key", {
  theme: "light",
  isLight: !0
}, {
  storageEnum: M.Local
}), H = {
  ...q,
  toggle: async () => {
    await q.set((e) => {
      const t = e.theme === "light" ? "dark" : "light";
      return {
        theme: t,
        isLight: t === "light"
      };
    });
  }
};
var _ = { exports: {} }, J = _.exports, z;
function K() {
  return z || (z = 1, (function(e, t) {
    (function(r, o) {
      o(e);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : J, function(r) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        r.exports = globalThis.browser;
      else {
        const o = "The message port closed before a response was received.", m = (l) => {
          const c = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(c).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class p extends WeakMap {
            constructor(n, i = void 0) {
              super(i), this.createItem = n;
            }
            get(n) {
              return this.has(n) || this.set(n, this.createItem(n)), super.get(n);
            }
          }
          const v = (s) => s && typeof s == "object" && typeof s.then == "function", S = (s, n) => (...i) => {
            l.runtime.lastError ? s.reject(new Error(l.runtime.lastError.message)) : n.singleCallbackArg || i.length <= 1 && n.singleCallbackArg !== !1 ? s.resolve(i[0]) : s.resolve(i);
          }, w = (s) => s == 1 ? "argument" : "arguments", F = (s, n) => function(g, ...d) {
            if (d.length < n.minArgs)
              throw new Error(`Expected at least ${n.minArgs} ${w(n.minArgs)} for ${s}(), got ${d.length}`);
            if (d.length > n.maxArgs)
              throw new Error(`Expected at most ${n.maxArgs} ${w(n.maxArgs)} for ${s}(), got ${d.length}`);
            return new Promise((f, h) => {
              if (n.fallbackToNoCallback)
                try {
                  g[s](...d, S({
                    resolve: f,
                    reject: h
                  }, n));
                } catch (a) {
                  console.warn(`${s} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, a), g[s](...d), n.fallbackToNoCallback = !1, n.noCallback = !0, f();
                }
              else n.noCallback ? (g[s](...d), f()) : g[s](...d, S({
                resolve: f,
                reject: h
              }, n));
            });
          }, N = (s, n, i) => new Proxy(n, {
            apply(g, d, f) {
              return i.call(d, s, ...f);
            }
          });
          let T = Function.call.bind(Object.prototype.hasOwnProperty);
          const C = (s, n = {}, i = {}) => {
            let g = /* @__PURE__ */ Object.create(null), d = {
              has(h, a) {
                return a in s || a in g;
              },
              get(h, a, b) {
                if (a in g)
                  return g[a];
                if (!(a in s))
                  return;
                let u = s[a];
                if (typeof u == "function")
                  if (typeof n[a] == "function")
                    u = N(s, s[a], n[a]);
                  else if (T(i, a)) {
                    let P = F(a, i[a]);
                    u = N(s, s[a], P);
                  } else
                    u = u.bind(s);
                else if (typeof u == "object" && u !== null && (T(n, a) || T(i, a)))
                  u = C(u, n[a], i[a]);
                else if (T(i, "*"))
                  u = C(u, n[a], i["*"]);
                else
                  return Object.defineProperty(g, a, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return s[a];
                    },
                    set(P) {
                      s[a] = P;
                    }
                  }), u;
                return g[a] = u, u;
              },
              set(h, a, b, u) {
                return a in g ? g[a] = b : s[a] = b, !0;
              },
              defineProperty(h, a, b) {
                return Reflect.defineProperty(g, a, b);
              },
              deleteProperty(h, a) {
                return Reflect.deleteProperty(g, a);
              }
            }, f = Object.create(s);
            return new Proxy(f, d);
          }, k = (s) => ({
            addListener(n, i, ...g) {
              n.addListener(s.get(i), ...g);
            },
            hasListener(n, i) {
              return n.hasListener(s.get(i));
            },
            removeListener(n, i) {
              n.removeListener(s.get(i));
            }
          }), R = new p((s) => typeof s != "function" ? s : function(i) {
            const g = C(i, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            s(g);
          }), A = new p((s) => typeof s != "function" ? s : function(i, g, d) {
            let f = !1, h, a = new Promise((L) => {
              h = function(y) {
                f = !0, L(y);
              };
            }), b;
            try {
              b = s(i, g, h);
            } catch (L) {
              b = Promise.reject(L);
            }
            const u = b !== !0 && v(b);
            if (b !== !0 && !u && !f)
              return !1;
            const P = (L) => {
              L.then((y) => {
                d(y);
              }, (y) => {
                let j;
                y && (y instanceof Error || typeof y.message == "string") ? j = y.message : j = "An unexpected error occurred", d({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: j
                });
              }).catch((y) => {
                console.error("Failed to send onMessage rejected reply", y);
              });
            };
            return P(u ? b : a), !0;
          }), E = ({
            reject: s,
            resolve: n
          }, i) => {
            l.runtime.lastError ? l.runtime.lastError.message === o ? n() : s(new Error(l.runtime.lastError.message)) : i && i.__mozWebExtensionPolyfillReject__ ? s(new Error(i.message)) : n(i);
          }, B = (s, n, i, ...g) => {
            if (g.length < n.minArgs)
              throw new Error(`Expected at least ${n.minArgs} ${w(n.minArgs)} for ${s}(), got ${g.length}`);
            if (g.length > n.maxArgs)
              throw new Error(`Expected at most ${n.maxArgs} ${w(n.maxArgs)} for ${s}(), got ${g.length}`);
            return new Promise((d, f) => {
              const h = E.bind(null, {
                resolve: d,
                reject: f
              });
              g.push(h), i.sendMessage(...g);
            });
          }, Z = {
            devtools: {
              network: {
                onRequestFinished: k(R)
              }
            },
            runtime: {
              onMessage: k(A),
              onMessageExternal: k(A),
              sendMessage: B.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: B.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, O = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return c.privacy = {
            network: {
              "*": O
            },
            services: {
              "*": O
            },
            websites: {
              "*": O
            }
          }, C(l, Z, c);
        };
        r.exports = m(chrome);
      }
    });
  })(_)), _.exports;
}
K();
H.get().then((e) => {
  console.log("theme", e);
});
console.log("Background loaded");
console.log("Edit 'chrome-extension/src/background/index.ts' and save to reload...");
const X = (e, t) => {
  if (!e || typeof e != "object")
    return null;
  const r = e, o = Array.isArray(r.alternativeSelectors) ? r.alternativeSelectors.filter(
    (l) => typeof l == "string" && l.trim().length > 0
  ) : [], m = r.confidence;
  return {
    bestSelector: typeof r.bestSelector == "string" && r.bestSelector.trim().length > 0 ? r.bestSelector : null,
    alternativeSelectors: o,
    reason: typeof r.reason == "string" ? r.reason : "",
    confidence: m === "low" || m === "medium" || m === "high" ? m : "unknown",
    targetStrategyId: typeof r.targetStrategyId == "string" ? r.targetStrategyId : void 0,
    failedStep: typeof r.failedStep == "string" ? r.failedStep : void 0,
    rawText: t
  };
}, Q = 12e3, D = [], G = (e) => {
  const t = D.indexOf(e);
  t >= 0 && D.splice(t, 1);
}, Y = (e, t) => {
  const r = [t.filename, t.finalUrl, t.url, t.referrer].filter(Boolean).join(" ").toLowerCase();
  return e.expectedUuid && !r.includes(e.expectedUuid.toLowerCase()) ? !1 : e.actionId === "download.single.wav" ? r.includes(".wav") || /\bwav\b/.test(r) : e.actionId === "download.single.mp3" ? r.includes(".mp3") || /\bmp3\b/.test(r) : !0;
}, ee = (e) => {
  const t = D.find((r) => Y(r, e));
  t && (G(t), clearTimeout(t.timeoutId), t.sendResponse({
    data: {
      downloadId: e.id,
      filename: e.filename,
      url: e.finalUrl || e.url
    }
  }));
};
chrome.downloads.onCreated.addListener((e) => {
  ee(e);
});
chrome.runtime.onMessage.addListener((e, t, r) => (console.log("Received message:", e, "from:", t), e.type === "requestSongs" ? (re(e, t).then((o) => r(o)).catch((o) => r({ error: o.message })), !0) : e.type === "geminiRecover" ? (ne(e.payload.apiKey, e.payload.prompt).then((o) => r(o)).catch(
  (o) => r({
    data: null,
    error: o instanceof Error ? o.message : "Gemini recovery failed."
  })
), !0) : e.type === "awaitDownloadStart" ? (se(e, r), !0) : !1));
const re = async (e, t) => {
  var l, c, p;
  console.log("handleRequestSongs called with payload:", e.payload), console.log("Sender tab:", (l = t.tab) == null ? void 0 : l.id, (c = t.tab) == null ? void 0 : c.url);
  const r = new FormData();
  (p = e.payload) != null && p.id && r.append("id", e.payload.id);
  const m = await (await fetch("http://192.168.86.99:9001/api/song-sets/gen-songs", {
    method: "POST",
    body: r
  })).json();
  return console.log("data", m), m;
}, se = (e, t) => {
  var m, l, c;
  const r = Math.max(1e3, ((m = e.payload) == null ? void 0 : m.timeoutMs) ?? Q), o = {
    sendResponse: t,
    expectedUuid: (l = e.payload) == null ? void 0 : l.uuid,
    actionId: (c = e.payload) == null ? void 0 : c.actionId,
    timeoutId: setTimeout(() => {
      G(o), t({
        data: null,
        error: `다운로드 시작을 ${r}ms 안에 감지하지 못했습니다.`
      });
    }, r)
  };
  D.push(o);
}, ne = async (e, t) => {
  var c, p, v, S;
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${e}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        generationConfig: {
          responseMimeType: "application/json",
          temperature: 0.2
        },
        contents: [
          {
            role: "user",
            parts: [{ text: t }]
          }
        ]
      })
    }
  );
  if (!r.ok) {
    const w = await r.text();
    throw new Error(`Gemini recovery failed: ${r.status} ${w}`);
  }
  const m = ((S = (v = (p = (c = (await r.json()).candidates) == null ? void 0 : c[0]) == null ? void 0 : p.content) == null ? void 0 : v.parts) == null ? void 0 : S.map((w) => w.text ?? "").join(`
`).trim()) ?? "";
  let l = null;
  if (m)
    try {
      l = X(JSON.parse(m), m);
    } catch {
      l = null;
    }
  return {
    data: {
      text: m,
      suggestion: l
    }
  };
};
